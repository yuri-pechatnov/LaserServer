$wnd.com_pechatnov_MyAppWidgetset.runAsyncCallback2('Bbb(1538,1,XSd);_.tc=function Wac(){gZb((!_Yb&&(_Yb=new lZb),_Yb),this.a.d)};zMd(Th)(2);\n//# sourceURL=com.pechatnov.MyAppWidgetset-2.js\n')
